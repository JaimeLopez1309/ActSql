package com.example.actsql.model;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.view.View;

import com.example.actsql.Entity.User;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;

public class UserDao {
    private ManagerDataBase managerDataBase;
    Context context;
    View view;
    private User user;

    public UserDao(Context context, View view) {
        this.context = context;
        this.view = view;
        managerDataBase =new ManagerDataBase(this.context);
    }
    public void InsertUser(User user){
        try {
            SQLiteDatabase db = managerDataBase.getWritableDatabase();
            if(db != null){
                ContentValues values = new ContentValues();
                values.put("use_document", user.getDocument());
                values.put("use_user", user.getUser());
                values.put("use_names", user.getNames());
                values.put("use_lastnames", user.getLastNames());
                values.put("use_password", user.getPassword());
                values.put("use_status", 1);
                Long cod = db.insert("users", null, values);
                Snackbar.make(this.view, "Se ha registrado el Usuario: "+ cod, Snackbar.LENGTH_LONG).show();
            }else {
                Snackbar.make(this.view, "NO se ha registrado el Usuario", Snackbar.LENGTH_LONG).show();
            }
        }catch (SQLException e){
            Log.i("BD", ""+e);
        }
    }
    public ArrayList<User> getUserList(){
        ArrayList<User> ListUser =new ArrayList<>();
        try {
            SQLiteDatabase db = managerDataBase.getReadableDatabase();
            String query ="select * from users where use_status = 1; ";
            Cursor cursor =db.rawQuery(query,null);
            if (cursor.moveToFirst()){
                do {
                    User user1 =new User();
                    user1.setDocument(cursor.getInt(0));
                    user1.setUser(cursor.getString(1));
                    user1.setNames(cursor.getString(2));
                    user1.setLastNames(cursor.getString(3));
                    user1.setPassword(cursor.getString(4));
                    ListUser.add(user1);
                }while (cursor.moveToNext());
            }
            cursor.close();
            db.close();
        }catch (SQLException e){
            Log.i("BD", ""+e);
        }
       return ListUser;

    }
}
