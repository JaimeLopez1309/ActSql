package com.example.actsql;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.actsql.Entity.User;
import com.example.actsql.model.UserDao;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static final String TAG = "Validate";
    private Context Context;
    private EditText EtDocumento;
    private EditText EtUsuario;
    private EditText EtNombres;
    private EditText EtApellidos;
    private EditText EtContra;
    private ListView ListUsers;
    private int documento;
    String usuario;
    String nombres;
    String apellidos;
    String contra;

    private Button BtnSave;
    private Button BtnListUsers;
    private Button BtnLimpiar;
    private Button BtnBuscar;

    SQLiteDatabase baseDatos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Context =this;
        InitObj();
        BtnSave.setOnClickListener(this::CreateUsers);
        BtnListUsers.setOnClickListener(this::ListUserShow);
        BtnLimpiar.setOnClickListener(this::LimpiarDatos);
        BtnBuscar.setOnClickListener(this::BuscarDatos);
    }

    private void BuscarDatos(View view) {
        /*UserDao dao= new UserDao(Context, findViewById(R.id.LvLista));
        ArrayList<User> users =dao.getUserList();
        do {
            user.
        }while(users!= null);*/
    }

    private void LimpiarDatos(View view) {
        EtDocumento.setText("");
        EtNombres.setText("");
        EtApellidos.setText("");
        EtUsuario.setText("");
        EtContra.setText("");
    }

    private void ListUserShow(View view) {
        UserDao dao= new UserDao(Context, findViewById(R.id.LvLista));
        ArrayList<User> users =dao.getUserList();
        ArrayAdapter<User> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, users);
        ListUsers.setAdapter(adapter);
    }

    private void CreateUsers(View view) {
        GetData();
        User user = new User(documento,nombres, apellidos,usuario,contra);
        UserDao dao = new UserDao(Context, view);
        dao.InsertUser(user);
        ListUserShow(view);
    }

    private void  GetData(){
        documento = Integer.parseInt(EtDocumento.getText().toString());
        usuario = EtUsuario.getText().toString();
        nombres = EtNombres.getText().toString();
        apellidos = EtApellidos.getText().toString();
        contra = EtContra.getText().toString();
    }
    private void InitObj(){
        BtnSave =findViewById(R.id.BtnREgistrar);
        BtnListUsers = findViewById(R.id.Btnlistar);
        EtNombres =findViewById(R.id.EtNombres);
        EtApellidos =  findViewById(R.id.Etapellidos);
        EtDocumento = findViewById(R.id.EtDocumento);
        EtUsuario = findViewById(R.id.EtUsuario);
        EtContra = findViewById(R.id.EtContra);
        ListUsers = findViewById(R.id.LvLista);
        BtnLimpiar = findViewById(R.id.BtnLimpiar);
        BtnBuscar = findViewById(R.id.BtnBuscar);
    }
}